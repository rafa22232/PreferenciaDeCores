package android.fabioclaret.modularpamifabioecleitonpreferenciasdecores;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button cor1, cor2, cor3, cor4, cor5, btnTrocar;
    LinearLayout tela;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        initComponents();

        btnTrocar.setOnContextClickListener(){

        }

        cor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cor = "#9C27B0";
                SalvarCor(cor);
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void SalvarCor(String cor) {

    }

    @SuppressLint("WrongViewCast")
    private void initComponents() {
        cor1 = findViewById(R.id.cor1);
        cor2 = findViewById(R.id.cor2);
        cor3 = findViewById(R.id.cor3);
        cor4 = findViewById(R.id.cor4);
        cor5 = findViewById(R.id.cor5);
        btnTrocar = findViewById(R.id.btn_trocar);
        tela = findViewById(R.id.main);

    }


}